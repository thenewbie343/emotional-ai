# 🎬 YouTube Pipeline — Complete Setup Guide
# Control everything from your phone while in Kashmir

---

## What You're Building

```
Your Phone (Telegram)
    ↓  ↑
Railway.app Server (Always-on, FREE)   ← brain of the system, runs 24/7
    ↓
Google Drive                           ← stores all state, assets, videos
    ↓
Google Colab T4 GPU (triggered)        ← heavy GPU work only (audio + assembly)
    ↓
YouTube API                            ← scheduled upload
```

---

## STEP 1 — Create Your Telegram Bot (5 minutes)

1. Open Telegram → search `@BotFather`
2. Send `/newbot`
3. Give it a name: `My YouTube Pipeline`
4. Give username: `myyoutubepipeline_bot`
5. **Copy the token** — looks like `7123456789:AAHxyz...`
6. Find your own user ID: search `@userinfobot`, send any message → copy your `Id`

---

## STEP 2 — Google Service Account (10 minutes)

1. Go to https://console.cloud.google.com
2. Create a new project: `youtube-pipeline`
3. Enable APIs:
   - Google Drive API
   - YouTube Data API v3
4. Go to **IAM & Admin → Service Accounts**
5. Create service account: `pipeline-bot`
6. Grant role: **Editor**
7. Click the account → **Keys** → **Add Key** → JSON
8. Download the JSON file — **keep it safe!**
9. Go to Google Drive → create folder `YouTube_Pipeline`
10. Right-click → Share → paste the service account email → Editor

---

## STEP 3 — Get Free API Keys

| Service | Where to Get | Free Limit |
|---------|-------------|-----------|
| OpenRouter | https://openrouter.ai (free credits) | Llama 3.3 free |
| DeepSeek | https://platform.deepseek.com | $5 free credit |
| Gemini | https://aistudio.google.com → Get API Key | 60 req/min free |
| Pexels | https://www.pexels.com/api | 200 req/hour free |
| Tavily | https://tavily.com | 1000 req/month free |
| HuggingFace | https://huggingface.co → Settings → Tokens | 4 free keys |
| ngrok | https://ngrok.com → Signup → Auth Token | 1 tunnel free |

---

## STEP 4 — Deploy Bot on Railway (10 minutes)

1. Go to https://railway.app → Sign up (free)
2. **New Project** → **Deploy from GitHub** 
   - Upload the `orchestrator/` folder to a new GitHub repo first
   - OR use **Deploy from template** → Python
3. Set all environment variables (Settings → Variables):

```
TELEGRAM_TOKEN=7123456789:AAHxyz...
ALLOWED_USER_ID=123456789
GOOGLE_SERVICE_ACCOUNT_JSON={"type":"service_account",...}   ← paste entire JSON
OPENROUTER_KEY=sk-or-...
DEEPSEEK_KEY=sk-...
GEMINI_KEY_1=AIza...
GEMINI_KEY_2=AIza...   ← get a second key from a second Google account
PEXELS_KEY=...
TAVILY_KEY=tvly-...
HF_KEY_1=hf_...
HF_KEY_2=hf_...
HF_KEY_3=hf_...
HF_KEY_4=hf_...
PIPELINE_SECRET=choose_any_secret_password_here
DRIVE_FOLDER_ROOT=YouTube_Pipeline
COLAB_TRIGGER_URL=   ← leave blank for now, fill in after Step 5
```

4. Click **Deploy** → wait 2 minutes → bot goes live!
5. Test: Open Telegram → find your bot → send `/start`

---

## STEP 5 — Setup Colab Worker (15 minutes)

1. Go to https://colab.research.google.com
2. Upload `colab_notebooks/pipeline_worker.ipynb`
3. **Runtime → Change runtime type → T4 GPU**
4. Add Colab Secrets (key icon in left sidebar):
   - `GOOGLE_SERVICE_ACCOUNT_JSON` → paste full JSON
   - `PIPELINE_SECRET` → same password as in Railway
   - `NGROK_TOKEN` → from ngrok.com

5. Run Cell 1 (install deps) → wait ~3 minutes
6. Run Cell 2 (secrets)
7. Run Cell 3 (Drive setup)
8. Run Cell 4 (audio functions)
9. Run Cell 5 (video functions)
10. Run Cell 6 (assembly runner)
11. Run **Cell 7** (Flask + ngrok) → **copy the ngrok URL** it prints

12. Go back to Railway → Settings → Variables
    - Set `COLAB_TRIGGER_URL` = the ngrok URL
    - Redeploy

---

## STEP 6 — Test the Full Pipeline

Send to your Telegram bot:
```
/start
→ tap "New Video Project"
→ Topic: "Bhagat Singh Documentary in Hindi"
→ Description: "Story of Bhagat Singh, focusing on his revolutionary activities and sacrifice for Indian independence"
→ Publish time: 2026-05-23 17:00
→ tap "Launch Pipeline"
```

Watch the bot send you updates as each stage completes!

---

## Using From Kashmir 🏔️

While you're away, the pipeline runs fully automatically. You only need to:

1. **Check status anytime**: send `/status` to bot
2. **Asset alerts**: if bot asks for a video clip, generate it on your phone using:
   - **Veo** (Google) — free AI video
   - **Luma AI** (Dream Machine) — free credits
   - **CapCut** — easy on phone
   Upload to the Drive folder link the bot sends you, then `/resume`

3. **If Colab disconnects** (happens after ~12hrs):
   - Open Colab app on phone
   - Run Cell 7 again
   - Bot automatically picks up where it left off (checkpoint.json)

---

## Troubleshooting

**Bot not responding**: Check Railway logs → Settings → Deployments → View Logs

**Colab disconnects during assembly**: 
- The checkpoint is saved to Drive
- Reopen Colab, run all cells, run the manual block in Cell 6
- It will resume from Drive state

**YouTube upload quota exceeded**: 
- Bot saves video + metadata to Drive
- Manual upload when you return (takes 2 minutes)

**API rate limits**:
- Gemini: bot auto-waits 60 seconds and retries
- HuggingFace: rotates through your 4 keys automatically
- Pexels: falls back to HuggingFace generation

---

## Cost Breakdown

| Service | Cost |
|---------|------|
| Railway (hobby plan) | $5/month OR free tier (limited hours) |
| Google Colab | FREE (T4 GPU, ~90 min sessions) |
| OpenRouter (Llama) | FREE |
| DeepSeek | ~$0.05 per video |
| Gemini | FREE (within limits) |
| Pexels | FREE |
| HuggingFace | FREE |
| Total | ~$0-5/month |

---

## File Structure in Google Drive

```
YouTube_Pipeline/
├── Project_1716000000/
│   ├── checkpoint.json          ← full pipeline state
│   ├── ManualAssets/            ← upload your clips here (scene_1.mp4 etc)
│   ├── Audio/                   ← generated voice files
│   └── Video/
│       └── Project_001_final.mp4
├── Approved_Uploads/            ← QC passed videos
├── Drafts/                      ← QC score 6-9 (needs polish)
└── Rejects/                     ← QC score 0-5
```
