"""
=============================================================
  AUTONOMOUS YOUTUBE PIPELINE — TELEGRAM BOT ORCHESTRATOR
  Runs 24/7 on Railway / Render free tier
  Controls full pipeline: research → script → audio → video → upload
=============================================================
"""

import os, json, asyncio, logging, time, csv, io
from datetime import datetime, timezone
from pathlib import Path
import httpx
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    CallbackQueryHandler, ContextTypes, filters
)
from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload, MediaFileUpload

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)

# ─── ENV VARS (set these in Railway/Render dashboard) ─────────────────────────
TELEGRAM_TOKEN        = os.environ["TELEGRAM_TOKEN"]
ALLOWED_USER_ID       = int(os.environ["ALLOWED_USER_ID"])   # your Telegram user ID
OPENROUTER_KEY        = os.environ["OPENROUTER_KEY"]
DEEPSEEK_KEY          = os.environ.get("DEEPSEEK_KEY", "")
GEMINI_KEY_1          = os.environ["GEMINI_KEY_1"]
GEMINI_KEY_2          = os.environ["GEMINI_KEY_2"]
PEXELS_KEY            = os.environ["PEXELS_KEY"]
TAVILY_KEY            = os.environ.get("TAVILY_KEY", "")
GOOGLE_CSE_KEY        = os.environ.get("GOOGLE_CSE_KEY", "")
GOOGLE_CSE_CX         = os.environ.get("GOOGLE_CSE_CX", "")
HF_KEY_1              = os.environ.get("HF_KEY_1", "")
HF_KEY_2              = os.environ.get("HF_KEY_2", "")
HF_KEY_3              = os.environ.get("HF_KEY_3", "")
HF_KEY_4              = os.environ.get("HF_KEY_4", "")
YOUTUBE_CLIENT_SECRET = os.environ.get("YOUTUBE_CLIENT_SECRET", "")
DRIVE_FOLDER_ROOT     = os.environ.get("DRIVE_FOLDER_ROOT", "YouTube_Pipeline")
COLAB_TRIGGER_URL     = os.environ.get("COLAB_TRIGGER_URL", "")  # ngrok/colab tunnel URL
# ──────────────────────────────────────────────────────────────────────────────

HF_KEYS = [k for k in [HF_KEY_1, HF_KEY_2, HF_KEY_3, HF_KEY_4] if k]

# In-memory state (backed by Drive checkpoint.json)
sessions: dict[int, dict] = {}   # user_id → project state
waiting_asset: dict[int, dict] = {}  # user_id → {scene_id, prompt} when paused for asset


# ══════════════════════════════════════════════════════════════════════════════
#  GOOGLE DRIVE HELPERS
# ══════════════════════════════════════════════════════════════════════════════
def get_drive_service():
    creds_json = json.loads(os.environ["GOOGLE_SERVICE_ACCOUNT_JSON"])
    creds = service_account.Credentials.from_service_account_info(
        creds_json, scopes=["https://www.googleapis.com/auth/drive"]
    )
    return build("drive", "v3", credentials=creds)

def drive_create_folder(service, name: str, parent_id: str = None) -> str:
    meta = {"name": name, "mimeType": "application/vnd.google-apps.folder"}
    if parent_id:
        meta["parents"] = [parent_id]
    f = service.files().create(body=meta, fields="id").execute()
    return f["id"]

def drive_find_or_create_folder(service, name: str, parent_id: str = None) -> str:
    q = f"name='{name}' and mimeType='application/vnd.google-apps.folder' and trashed=false"
    if parent_id:
        q += f" and '{parent_id}' in parents"
    results = service.files().list(q=q, fields="files(id,name)").execute().get("files", [])
    if results:
        return results[0]["id"]
    return drive_create_folder(service, name, parent_id)

def drive_upload_json(service, data: dict, filename: str, folder_id: str) -> str:
    content = json.dumps(data, indent=2, ensure_ascii=False).encode()
    media = MediaFileUpload(io.BytesIO(content), mimetype="application/json")
    # Delete old version if exists
    q = f"name='{filename}' and '{folder_id}' in parents and trashed=false"
    old = service.files().list(q=q, fields="files(id)").execute().get("files", [])
    for o in old:
        service.files().delete(fileId=o["id"]).execute()
    file_meta = {"name": filename, "parents": [folder_id]}
    f = service.files().create(body=file_meta, media_body=media, fields="id").execute()
    return f["id"]

def drive_read_json(service, filename: str, folder_id: str) -> dict | None:
    q = f"name='{filename}' and '{folder_id}' in parents and trashed=false"
    results = service.files().list(q=q, fields="files(id)").execute().get("files", [])
    if not results:
        return None
    fid = results[0]["id"]
    req = service.files().get_media(fileId=fid)
    buf = io.BytesIO()
    dl = MediaIoBaseDownload(buf, req)
    done = False
    while not done:
        _, done = dl.next_chunk()
    return json.loads(buf.getvalue())

def save_checkpoint(project_state: dict):
    try:
        svc = get_drive_service()
        folder_id = project_state.get("folder_id")
        if folder_id:
            drive_upload_json(svc, project_state, "checkpoint.json", folder_id)
    except Exception as e:
        log.warning(f"Checkpoint save failed: {e}")


# ══════════════════════════════════════════════════════════════════════════════
#  LLM HELPERS
# ══════════════════════════════════════════════════════════════════════════════
async def call_openrouter(messages: list, model="meta-llama/llama-3.3-70b-instruct", max_tokens=2000) -> str:
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers={"Authorization": f"Bearer {OPENROUTER_KEY}", "Content-Type": "application/json"},
            json={"model": model, "messages": messages, "max_tokens": max_tokens}
        )
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"]

async def call_deepseek(messages: list, max_tokens=4000) -> str:
    """DeepSeek V3 for script generation. Falls back to Gemini if unavailable."""
    try:
        async with httpx.AsyncClient(timeout=90) as client:
            r = await client.post(
                "https://api.deepseek.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {DEEPSEEK_KEY}", "Content-Type": "application/json"},
                json={"model": "deepseek-chat", "messages": messages, "max_tokens": max_tokens}
            )
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"]
    except Exception as e:
        log.warning(f"DeepSeek failed ({e}), falling back to Gemini")
        return await call_gemini(messages[-1]["content"], key=GEMINI_KEY_1, max_tokens=max_tokens)

async def call_gemini(prompt: str, key: str = None, max_tokens: int = 2000) -> str:
    key = key or GEMINI_KEY_1
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post(
            f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent?key={key}",
            json={"contents": [{"parts": [{"text": prompt}]}],
                  "generationConfig": {"maxOutputTokens": max_tokens}}
        )
        r.raise_for_status()
        return r.json()["candidates"][0]["content"]["parts"][0]["text"]


# ══════════════════════════════════════════════════════════════════════════════
#  STAGE 2: WEB RESEARCH WATERFALL
# ══════════════════════════════════════════════════════════════════════════════
async def stage_research(topic: str, description: str) -> dict:
    """Returns {queries: [...], articles: [...], images: [...]}"""
    log.info(f"Stage 2: Research for '{topic}'")

    # Step A: Generate search queries with Llama
    query_prompt = f"""You are a research planner for documentary videos.
Topic: {topic}
Description: {description}

Generate exactly 3 highly specific search queries to find:
1. Historical facts and timeline
2. Key people and events  
3. Visual/photographic content

Respond ONLY with a JSON array: ["query1", "query2", "query3"]"""

    queries_raw = await call_openrouter([{"role": "user", "content": query_prompt}],
                                        model="meta-llama/llama-3.3-70b-instruct")
    try:
        queries = json.loads(queries_raw.strip().strip("```json").strip("```"))
    except Exception:
        queries = [topic, f"{topic} history", f"{topic} images"]

    articles, images = [], []

    for query in queries:
        # Tier 1: Wikimedia
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                r = await client.get(
                    "https://en.wikipedia.org/w/api.php",
                    params={"action": "query", "list": "search", "srsearch": query,
                            "format": "json", "srlimit": 3}
                )
                for item in r.json().get("query", {}).get("search", []):
                    articles.append({"source": "wikipedia", "title": item["title"],
                                      "snippet": item["snippet"]})
        except Exception as e:
            log.warning(f"Wikipedia tier failed: {e}")

        # Tier 2: DuckDuckGo (no API key needed)
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                r = await client.get(
                    "https://api.duckduckgo.com/",
                    params={"q": query, "format": "json", "no_html": "1", "skip_disambig": "1"}
                )
                data = r.json()
                if data.get("AbstractText"):
                    articles.append({"source": "duckduckgo", "title": data.get("Heading", query),
                                      "snippet": data["AbstractText"][:500]})
                for topic_item in data.get("RelatedTopics", [])[:3]:
                    if isinstance(topic_item, dict) and topic_item.get("Text"):
                        articles.append({"source": "duckduckgo_related",
                                          "snippet": topic_item["Text"][:300]})
        except Exception as e:
            log.warning(f"DuckDuckGo tier failed: {e}")

        # Tier 3: Tavily (if key available)
        if TAVILY_KEY:
            try:
                async with httpx.AsyncClient(timeout=15) as client:
                    r = await client.post(
                        "https://api.tavily.com/search",
                        json={"api_key": TAVILY_KEY, "query": query, "max_results": 3}
                    )
                    for res in r.json().get("results", []):
                        articles.append({"source": "tavily", "title": res.get("title", ""),
                                          "snippet": res.get("content", "")[:500], "url": res.get("url")})
            except Exception as e:
                log.warning(f"Tavily tier failed: {e}")

        # Tier 4: Google CSE (last resort)
        if GOOGLE_CSE_KEY and GOOGLE_CSE_CX and len(images) < 5:
            try:
                async with httpx.AsyncClient(timeout=10) as client:
                    r = await client.get(
                        "https://www.googleapis.com/customsearch/v1",
                        params={"key": GOOGLE_CSE_KEY, "cx": GOOGLE_CSE_CX,
                                "q": query, "searchType": "image", "num": 3}
                    )
                    for item in r.json().get("items", []):
                        images.append({"url": item["link"], "title": item["title"],
                                        "query": query, "source": "google_cse"})
            except Exception as e:
                log.warning(f"Google CSE tier failed: {e}")

        await asyncio.sleep(0.5)  # rate limit courtesy

    return {"queries": queries, "articles": articles[:15], "images": images[:10]}


# ══════════════════════════════════════════════════════════════════════════════
#  STAGE 3: SCRIPTING LOOP
# ══════════════════════════════════════════════════════════════════════════════
async def stage_generate_script(topic: str, description: str, research: dict) -> list[dict]:
    """Returns list of scene dicts with voiceover, visual plan, fallback prompts."""
    log.info("Stage 3: Generating script")

    research_text = "\n".join([
        f"- [{a['source']}] {a.get('title','')}: {a['snippet']}"
        for a in research["articles"]
    ])

    script_prompt = f"""You are a world-class documentary scriptwriter specializing in Hindi/Hinglish viral YouTube content.

TOPIC: {topic}
DESCRIPTION: {description}

RESEARCH MATERIAL:
{research_text}

Write an 8-minute, highly engaging documentary script. Output ONLY a valid JSON array of scene objects.
Each scene must have EXACTLY these fields:
- scene_number (integer, starting 1)
- duration_seconds (integer, 8-15 seconds per scene, ~40 scenes total)
- voiceover_text (string, in English or Hinglish, 1-3 sentences, highly engaging)
- on_screen_headline (string, 2-5 words in CAPS, shown as subtitle)
- visual_source (string: "scrape_real" OR "generate_ai" OR "pexels_stock")
- visual_search_query (string, for scraping or Pexels search)
- ai_fallback_prompt (string, detailed cinematic prompt if AI generation needed)
- emotion_note (string: "dramatic", "hopeful", "somber", "triumphant", "tense")

Rules:
- First scene: EXTREMELY strong hook, starts with a shocking fact or question
- Vary emotional tone across scenes
- Make voiceover conversational and retain attention
- Visual search queries must be specific and searchable
- AI prompts must be cinematic, detailed, no watermarks

Respond ONLY with the JSON array, no other text."""

    max_attempts = 3
    scenes = None

    for attempt in range(max_attempts):
        try:
            raw = await call_deepseek([{"role": "user", "content": script_prompt}], max_tokens=6000)
            # Clean JSON
            raw = raw.strip()
            if raw.startswith("```"):
                raw = raw.split("```")[1]
                if raw.startswith("json"):
                    raw = raw[4:]
            scenes = json.loads(raw.strip())
            break
        except Exception as e:
            log.warning(f"Script gen attempt {attempt+1} failed: {e}")
            await asyncio.sleep(5)

    if not scenes:
        raise RuntimeError("Script generation failed after all attempts")

    # Stage 3 critic: Gemini evaluates the script
    critic_prompt = f"""You are a viral YouTube retention expert. 
Score this script on a scale of 1-10 for:
1. Hook strength (first 3 seconds)
2. Emotional variety across scenes  
3. Visual feasibility (can assets be found/generated?)
4. Hinglish linguistic flow
5. Overall retention likelihood

Script summary (first 5 scenes): {json.dumps(scenes[:5], indent=2)}

If total score < 8/10, respond with: REWRITE: [specific improvements needed]
If score >= 8/10, respond with: APPROVED: [score]/10 [brief reason]"""

    try:
        critic_result = await call_gemini(critic_prompt, key=GEMINI_KEY_1)
        if critic_result.strip().startswith("REWRITE:"):
            log.info("Gemini critic requested rewrite. Running second pass.")
            improvement = critic_result.replace("REWRITE:", "").strip()
            script_prompt_v2 = script_prompt + f"\n\nIMPROVEMENT NOTES FROM REVIEWER:\n{improvement}\nApply these improvements."
            raw2 = await call_deepseek([{"role": "user", "content": script_prompt_v2}], max_tokens=6000)
            raw2 = raw2.strip().strip("```json").strip("```")
            scenes = json.loads(raw2.strip())
    except Exception as e:
        log.warning(f"Critic stage failed (continuing): {e}")

    return scenes


# ══════════════════════════════════════════════════════════════════════════════
#  STAGE 4: AUDIO — TRIGGERS COLAB OR FALLS BACK TO EDGE-TTS
# ══════════════════════════════════════════════════════════════════════════════
async def stage_trigger_audio(scenes: list[dict], project_folder_id: str) -> dict:
    """
    Sends scene voiceover data to Colab via webhook, or falls back to edge-tts cloud route.
    Returns status dict.
    """
    log.info("Stage 4: Audio generation")

    audio_manifest = [
        {"scene_id": s["scene_number"], "text": s["voiceover_text"],
         "duration_hint": s["duration_seconds"]}
        for s in scenes
    ]

    # Try Colab trigger first (if tunnel URL configured)
    if COLAB_TRIGGER_URL:
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                r = await client.post(
                    f"{COLAB_TRIGGER_URL}/audio",
                    json={"manifest": audio_manifest, "folder_id": project_folder_id},
                    headers={"X-Pipeline-Key": os.environ.get("PIPELINE_SECRET", "secret123")}
                )
                if r.status_code == 200:
                    return {"method": "colab_kokoro", "status": "triggered", "job_id": r.json().get("job_id")}
        except Exception as e:
            log.warning(f"Colab trigger failed: {e} — falling back to edge-tts route")

    # Fallback: Schedule edge-tts generation (runs on orchestrator server itself)
    return {"method": "edge_tts_fallback", "status": "queued", "manifest": audio_manifest}


# ══════════════════════════════════════════════════════════════════════════════
#  STAGE 5: VISUAL ASSET SOURCING
# ══════════════════════════════════════════════════════════════════════════════
async def fetch_pexels_video(query: str) -> str | None:
    """Returns a Pexels video download URL or None."""
    if not PEXELS_KEY:
        return None
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.get(
                "https://api.pexels.com/videos/search",
                headers={"Authorization": PEXELS_KEY},
                params={"query": query, "per_page": 3, "orientation": "landscape"}
            )
            videos = r.json().get("videos", [])
            if videos:
                # Get medium quality file
                for vf in videos[0].get("video_files", []):
                    if vf.get("quality") in ("hd", "sd") and vf.get("width", 0) >= 1280:
                        return vf["link"]
    except Exception as e:
        log.warning(f"Pexels failed for '{query}': {e}")
    return None

async def fetch_pexels_image(query: str) -> str | None:
    """Returns a Pexels image URL or None."""
    if not PEXELS_KEY:
        return None
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.get(
                "https://api.pexels.com/v1/search",
                headers={"Authorization": PEXELS_KEY},
                params={"query": query, "per_page": 3, "orientation": "landscape"}
            )
            photos = r.json().get("photos", [])
            if photos:
                return photos[0]["src"]["original"]
    except Exception as e:
        log.warning(f"Pexels image failed for '{query}': {e}")
    return None

async def generate_hf_image(prompt: str) -> bytes | None:
    """Try HuggingFace Wan 2.1 / Flux with key rotation."""
    hf_models = [
        "black-forest-labs/FLUX.1-dev",
        "stabilityai/stable-diffusion-xl-base-1.0"
    ]
    for key in HF_KEYS:
        for model in hf_models:
            try:
                async with httpx.AsyncClient(timeout=60) as client:
                    r = await client.post(
                        f"https://api-inference.huggingface.co/models/{model}",
                        headers={"Authorization": f"Bearer {key}"},
                        json={"inputs": prompt, "parameters": {"width": 1920, "height": 1080}}
                    )
                    if r.status_code == 200 and r.headers.get("content-type", "").startswith("image"):
                        return r.content
                    elif r.status_code == 429:
                        log.warning(f"HF rate limit on key {key[:8]}..., rotating")
                        continue
            except Exception as e:
                log.warning(f"HF generation failed: {e}")
    return None

async def source_visual_asset(scene: dict, drive_manual_folder_id: str) -> dict:
    """
    Returns asset info dict: {type: 'video'|'image'|'pexels'|'hf_generated'|'needs_human',
                               url: str|None, data: bytes|None, scene_id: int}
    """
    scene_id = scene["scene_number"]
    query = scene.get("visual_search_query", scene.get("on_screen_headline", "documentary footage"))
    ai_prompt = scene.get("ai_fallback_prompt", f"Cinematic shot of {query}")

    # Step 1: Check Drive manual uploads folder (user-provided clips named scene_N.mp4)
    try:
        svc = get_drive_service()
        q = f"name='scene_{scene_id}.mp4' and '{drive_manual_folder_id}' in parents and trashed=false"
        results = svc.files().list(q=q, fields="files(id,name)").execute().get("files", [])
        if results:
            return {"type": "drive_manual", "file_id": results[0]["id"], "scene_id": scene_id}
    except Exception as e:
        log.warning(f"Drive manual check failed: {e}")

    # Step 2: Pexels stock
    pexels_url = await fetch_pexels_video(query)
    if pexels_url:
        return {"type": "pexels_video", "url": pexels_url, "scene_id": scene_id}

    pexels_img = await fetch_pexels_image(query)
    if pexels_img:
        return {"type": "pexels_image", "url": pexels_img, "scene_id": scene_id}

    # Step 3: HuggingFace AI generation
    if scene.get("visual_source") == "generate_ai":
        img_data = await generate_hf_image(ai_prompt)
        if img_data:
            return {"type": "hf_generated", "data": img_data, "scene_id": scene_id,
                    "prompt": ai_prompt}

    # Step 4: Human fallback — return marker so bot can ask user
    return {"type": "needs_human", "scene_id": scene_id, "prompt": ai_prompt, "query": query}


# ══════════════════════════════════════════════════════════════════════════════
#  STAGE 8: YOUTUBE METADATA GENERATION
# ══════════════════════════════════════════════════════════════════════════════
async def generate_youtube_metadata(topic: str, scenes: list[dict]) -> dict:
    """Generate optimized title, description, tags via DeepSeek."""
    scene_titles = [s["on_screen_headline"] for s in scenes[:15]]
    timestamps_hint = "\n".join(
        [f"00:{i*30:02d} - {t}" for i, t in enumerate(scene_titles[:10])]
    )

    meta_prompt = f"""You are a YouTube SEO expert specializing in Hindi documentary channels.

Topic: {topic}
Scene headlines: {scene_titles}

Generate optimized YouTube metadata as JSON with:
- title (string, max 60 chars, clickbait but accurate, mix Hindi/English)
- description (string, 500-800 chars with timestamps section:\n{timestamps_hint}\n, hashtags, call to action)
- tags (array of 15 strings, mix Hindi transliterated + English keywords)
- category_id (string, "22" for People & Blogs, "27" for Education)

Respond ONLY with valid JSON."""

    raw = await call_deepseek([{"role": "user", "content": meta_prompt}])
    raw = raw.strip().strip("```json").strip("```").strip()
    return json.loads(raw)


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN PIPELINE RUNNER
# ══════════════════════════════════════════════════════════════════════════════
async def run_pipeline(user_id: int, topic: str, description: str,
                       publish_at: str, context: ContextTypes.DEFAULT_TYPE):
    """Full pipeline execution with per-stage Telegram updates."""
    bot = context.bot
    project_id = f"Project_{int(time.time())}"

    async def msg(text: str):
        await bot.send_message(chat_id=user_id, text=text, parse_mode="Markdown")

    # Setup Drive folders
    await msg(f"🚀 *Pipeline started!*\nProject: `{project_id}`\nTopic: {topic}")

    state = {
        "project_id": project_id, "topic": topic, "description": description,
        "publish_at": publish_at, "stage": 1, "status": "running",
        "started_at": datetime.now(timezone.utc).isoformat(),
        "folder_id": None, "manual_assets_folder_id": None
    }

    try:
        svc = get_drive_service()
        root_id = drive_find_or_create_folder(svc, DRIVE_FOLDER_ROOT)
        proj_id = drive_find_or_create_folder(svc, project_id, root_id)
        manual_id = drive_find_or_create_folder(svc, "ManualAssets", proj_id)
        audio_id = drive_find_or_create_folder(svc, "Audio", proj_id)
        video_id = drive_find_or_create_folder(svc, "Video", proj_id)
        state["folder_id"] = proj_id
        state["manual_assets_folder_id"] = manual_id
        state["audio_folder_id"] = audio_id
        state["video_folder_id"] = video_id
        sessions[user_id] = state
        save_checkpoint(state)
        await msg(f"📁 Drive folders created.\nUpload manual clips to: `{project_id}/ManualAssets/`\nName them `scene_1.mp4`, `scene_2.mp4` etc.")
    except Exception as e:
        await msg(f"⚠️ Drive setup failed: {e}\nContinuing without Drive backup.")

    # ── Stage 2: Research ──────────────────────────────────────────────────
    state["stage"] = 2
    save_checkpoint(state)
    await msg("🔍 *Stage 2/8:* Running web research waterfall...")
    try:
        research = await stage_research(topic, description)
        state["research"] = research
        await msg(f"✅ Research complete: {len(research['articles'])} articles, {len(research['images'])} images found")
    except Exception as e:
        await msg(f"⚠️ Research failed: {e}. Continuing with base description.")
        research = {"queries": [topic], "articles": [], "images": []}
        state["research"] = research

    # ── Stage 3: Script ────────────────────────────────────────────────────
    state["stage"] = 3
    save_checkpoint(state)
    await msg("✍️ *Stage 3/8:* Generating script with DeepSeek + Gemini critique...")
    try:
        scenes = await stage_generate_script(topic, description, research)
        state["scenes"] = scenes
        total_duration = sum(s.get("duration_seconds", 10) for s in scenes)
        await msg(f"✅ Script ready: *{len(scenes)} scenes*, ~{total_duration//60}m {total_duration%60}s total")
        save_checkpoint(state)
    except Exception as e:
        await msg(f"❌ Script generation failed: {e}")
        state["status"] = "failed"
        save_checkpoint(state)
        return

    # ── Stage 4: Audio ─────────────────────────────────────────────────────
    state["stage"] = 4
    save_checkpoint(state)
    await msg("🎙️ *Stage 4/8:* Triggering audio generation (Kokoro/edge-tts)...")
    try:
        audio_result = await stage_trigger_audio(scenes, state.get("audio_folder_id", ""))
        state["audio_result"] = audio_result
        method = audio_result.get("method", "unknown")
        await msg(f"✅ Audio queued via `{method}`")
        if method == "edge_tts_fallback":
            await msg("💡 _Tip: Open your Colab notebook and run the audio cell to use Kokoro GPU for better quality._")
    except Exception as e:
        await msg(f"⚠️ Audio trigger failed: {e}")

    # ── Stage 5: Visual Assets ─────────────────────────────────────────────
    state["stage"] = 5
    save_checkpoint(state)
    await msg(f"🎬 *Stage 5/8:* Sourcing visual assets for {len(scenes)} scenes...")

    assets = []
    human_needed = []

    for i, scene in enumerate(scenes):
        asset = await source_visual_asset(scene, state.get("manual_assets_folder_id", ""))
        assets.append(asset)
        if asset["type"] == "needs_human":
            human_needed.append(asset)

        if (i + 1) % 10 == 0:
            await msg(f"  📦 Asset progress: {i+1}/{len(scenes)} scenes processed")

        await asyncio.sleep(0.3)

    state["assets"] = [
        {k: v for k, v in a.items() if k != "data"}  # don't save binary data to checkpoint
        for a in assets
    ]
    save_checkpoint(state)

    # Handle human-needed assets
    if human_needed:
        state["status"] = "paused_for_assets"
        state["human_needed"] = human_needed
        save_checkpoint(state)

        scenes_list = "\n".join([
            f"  • Scene {a['scene_id']}: _{a['prompt'][:80]}_"
            for a in human_needed[:5]
        ])
        if len(human_needed) > 5:
            scenes_list += f"\n  ...and {len(human_needed)-5} more"

        await msg(
            f"⚠️ *Asset Alert!* {len(human_needed)} scenes need manual assets:\n{scenes_list}\n\n"
            f"Please generate video clips using Veo / Luma / CapCut and upload them to:\n"
            f"`{project_id}/ManualAssets/` — name them `scene_N.mp4`\n\n"
            f"Then send `/resume` to continue the pipeline."
        )
        waiting_asset[user_id] = {"project_id": project_id, "scenes": human_needed}
        return

    auto_count = len([a for a in assets if a["type"] != "needs_human"])
    await msg(f"✅ Assets sourced: {auto_count}/{len(scenes)} automatically")

    await continue_pipeline_after_assets(user_id, state, assets, context)


async def continue_pipeline_after_assets(user_id: int, state: dict, assets: list,
                                          context: ContextTypes.DEFAULT_TYPE):
    """Stages 6-8: Video assembly, QC, and YouTube upload."""
    bot = context.bot

    async def msg(text: str):
        await bot.send_message(chat_id=user_id, text=text, parse_mode="Markdown")

    # ── Stage 6: Video Assembly ────────────────────────────────────────────
    state["stage"] = 6
    save_checkpoint(state)
    await msg("🎞️ *Stage 6/8:* Assembling video (FFmpeg + subtitles)...")

    # Build assembly manifest for Colab or server-side FFmpeg
    assembly_manifest = {
        "project_id": state["project_id"],
        "scenes": state["scenes"],
        "assets": state.get("assets", []),
        "audio_result": state.get("audio_result", {}),
        "output_folder_id": state.get("video_folder_id", "")
    }

    state["assembly_manifest"] = assembly_manifest
    save_checkpoint(state)

    if COLAB_TRIGGER_URL:
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                r = await client.post(
                    f"{COLAB_TRIGGER_URL}/assemble",
                    json=assembly_manifest,
                    headers={"X-Pipeline-Key": os.environ.get("PIPELINE_SECRET", "secret123")}
                )
                if r.status_code == 200:
                    await msg(f"✅ Assembly job sent to Colab. Job ID: `{r.json().get('job_id', 'N/A')}`")
                    await msg("⏳ Assembly takes 15-30 mins. I'll notify you when done.\nYou can check anytime with `/status`")
                    state["status"] = "assembling"
                    state["stage"] = 6
                    save_checkpoint(state)
                    return
        except Exception as e:
            log.warning(f"Colab assembly trigger failed: {e}")

    await msg("⚠️ Colab not connected. Assembly manifest saved to Drive.\n"
              "Open your Colab notebook → run the assembly cell → it will auto-detect the manifest.")

    # ── Stage 7: QC (placeholder — Colab sends result back) ───────────────
    state["stage"] = 7
    state["status"] = "waiting_qc"
    save_checkpoint(state)

    # ── Stage 8: YouTube Metadata ──────────────────────────────────────────
    await msg("📝 *Stage 8/8:* Generating YouTube metadata...")
    try:
        metadata = await generate_youtube_metadata(state["topic"], state["scenes"])
        state["youtube_metadata"] = metadata
        save_checkpoint(state)

        await msg(
            f"✅ *Metadata ready!*\n\n"
            f"📌 *Title:* {metadata.get('title', 'N/A')}\n"
            f"🏷️ *Tags:* {', '.join(metadata.get('tags', [])[:5])}...\n\n"
            f"Video will be scheduled for: `{state['publish_at']}`"
        )
    except Exception as e:
        await msg(f"⚠️ Metadata generation failed: {e}")

    state["status"] = "complete_pending_assembly"
    save_checkpoint(state)
    await msg("🎯 *Pipeline complete!* Video assembly is running on Colab.\n"
              "You'll get a notification when the video is ready to upload.")


# ══════════════════════════════════════════════════════════════════════════════
#  TELEGRAM COMMAND HANDLERS
# ══════════════════════════════════════════════════════════════════════════════
def auth_check(func):
    """Decorator: only allow your user ID."""
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if update.effective_user.id != ALLOWED_USER_ID:
            await update.message.reply_text("⛔ Unauthorized.")
            return
        return await func(update, context)
    return wrapper

@auth_check
async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Multi-step project setup via inline keyboard."""
    keyboard = [
        [InlineKeyboardButton("📹 New Video Project", callback_data="new_project")],
        [InlineKeyboardButton("📊 Check Status", callback_data="check_status")],
        [InlineKeyboardButton("📖 Help", callback_data="help")],
    ]
    await update.message.reply_text(
        "🎬 *YouTube Pipeline Bot*\nWhat would you like to do?",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )

@auth_check
async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    state = sessions.get(user_id)

    # Try loading from Drive if not in memory
    if not state:
        try:
            svc = get_drive_service()
            root_id = drive_find_or_create_folder(svc, DRIVE_FOLDER_ROOT)
            # Find most recent project folder
            q = f"'{root_id}' in parents and mimeType='application/vnd.google-apps.folder' and trashed=false"
            folders = svc.files().list(q=q, orderBy="createdTime desc",
                                       fields="files(id,name)", pageSize=1).execute().get("files", [])
            if folders:
                checkpoint = drive_read_json(svc, "checkpoint.json", folders[0]["id"])
                if checkpoint:
                    state = checkpoint
                    sessions[user_id] = state
        except Exception as e:
            log.warning(f"Could not load checkpoint: {e}")

    if not state:
        await update.message.reply_text(
            "💤 *No active project.*\nSend /start to create a new video.", parse_mode="Markdown"
        )
        return

    stage_names = {
        1: "🚀 Booting up",
        2: "🔍 Web research",
        3: "✍️ Script generation",
        4: "🎙️ Audio generation",
        5: "🎬 Visual asset sourcing",
        6: "🎞️ Video assembly",
        7: "🧪 Quality control",
        8: "📤 YouTube upload"
    }

    stage = state.get("stage", 1)
    status = state.get("status", "unknown")
    topic = state.get("topic", "Unknown")
    started = state.get("started_at", "")[:19]

    msg = (
        f"📊 *Pipeline Status*\n\n"
        f"🎯 Topic: {topic}\n"
        f"📍 Stage: {stage}/8 — {stage_names.get(stage, 'Unknown')}\n"
        f"🔄 Status: `{status}`\n"
        f"⏰ Started: {started}\n"
    )

    if status == "paused_for_assets":
        needed = state.get("human_needed", [])
        msg += f"\n⚠️ *Paused:* {len(needed)} scenes need your video clips\nSend /resume after uploading to Drive"

    await update.message.reply_text(msg, parse_mode="Markdown")

@auth_check
async def cmd_resume(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    state = sessions.get(user_id)
    if not state or state.get("status") != "paused_for_assets":
        await update.message.reply_text("No paused project found.")
        return
    await update.message.reply_text("▶️ Resuming pipeline...")
    state["status"] = "running"
    if user_id in waiting_asset:
        del waiting_asset[user_id]
    # Re-source assets and continue
    await continue_pipeline_after_assets(user_id, state, state.get("assets", []), context)

@auth_check
async def cmd_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id in sessions:
        sessions[user_id]["status"] = "cancelled"
        save_checkpoint(sessions[user_id])
        del sessions[user_id]
    if user_id in waiting_asset:
        del waiting_asset[user_id]
    await update.message.reply_text("🛑 Pipeline cancelled.")

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id

    if user_id != ALLOWED_USER_ID:
        return

    if query.data == "new_project":
        context.user_data["setup_step"] = "topic"
        await query.message.reply_text(
            "🎯 *Step 1/3: Enter your video topic*\n\nExamples:\n"
            "• Bhagat Singh ki kahaani\n• India vs Pakistan 1971 War Documentary\n• ChatGPT history in Hindi",
            parse_mode="Markdown"
        )

    elif query.data == "check_status":
        # Trigger status command
        class FakeUpdate:
            effective_user = query.from_user
            message = query.message
        await cmd_status(FakeUpdate(), context)

    elif query.data == "help":
        await query.message.reply_text(
            "📖 *Bot Commands*\n\n"
            "/start — Start new project or open menu\n"
            "/status — Check current pipeline status\n"
            "/resume — Resume after uploading manual assets\n"
            "/cancel — Cancel current project\n\n"
            "💡 *How it works:*\n"
            "1. You send a topic\n"
            "2. Bot researches, scripts, generates audio\n"
            "3. Fetches/generates visuals automatically\n"
            "4. Assembles & schedules to YouTube\n"
            "5. You stay in Kashmir 🏔️",
            parse_mode="Markdown"
        )

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id != ALLOWED_USER_ID:
        return

    text = update.message.text or ""
    step = context.user_data.get("setup_step")

    if step == "topic":
        context.user_data["topic"] = text
        context.user_data["setup_step"] = "description"
        await update.message.reply_text(
            "📝 *Step 2/3: Brief description*\n\nAdd key facts, angle, or mood. 2-3 sentences.\n"
            "Or send /skip to use the topic only.",
            parse_mode="Markdown"
        )

    elif step == "description":
        if text == "/skip":
            text = context.user_data.get("topic", "")
        context.user_data["description"] = text
        context.user_data["setup_step"] = "publish_time"
        await update.message.reply_text(
            "⏰ *Step 3/3: Publish date & time*\n\nFormat: `YYYY-MM-DD HH:MM` (24hr, IST)\n"
            "Example: `2026-05-23 17:00`\n\nOr send /skip for default (tomorrow 5pm IST)",
            parse_mode="Markdown"
        )

    elif step == "publish_time":
        if text == "/skip":
            from datetime import timedelta
            tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d 17:00")
            text = tomorrow
        context.user_data["publish_at"] = text
        context.user_data["setup_step"] = None

        topic = context.user_data.get("topic", "")
        description = context.user_data.get("description", "")
        publish_at = text

        keyboard = [
            [InlineKeyboardButton("✅ Launch Pipeline", callback_data="confirm_launch")],
            [InlineKeyboardButton("❌ Cancel", callback_data="cancel_launch")],
        ]
        await update.message.reply_text(
            f"🎬 *Ready to launch!*\n\n"
            f"📌 Topic: {topic}\n"
            f"📝 Description: {description[:100]}...\n"
            f"⏰ Publish: {publish_at}\n\n"
            f"Start the pipeline?",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode="Markdown"
        )
        context.user_data["pending_launch"] = {"topic": topic, "description": description,
                                                 "publish_at": publish_at}

    # Handle confirm/cancel from inline keyboard (set in callback handler)

async def handle_confirm_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id

    if query.data == "confirm_launch":
        pending = context.user_data.get("pending_launch")
        if pending:
            asyncio.create_task(
                run_pipeline(user_id, pending["topic"], pending["description"],
                             pending["publish_at"], context)
            )
    elif query.data == "cancel_launch":
        await query.message.reply_text("❌ Cancelled. Send /start to try again.")


# ══════════════════════════════════════════════════════════════════════════════
#  CSV FALLBACK WATCHER (runs in background if Telegram is unreachable)
# ══════════════════════════════════════════════════════════════════════════════
async def csv_watcher(context: ContextTypes.DEFAULT_TYPE):
    """Every 5 minutes, check Drive for input.csv with new rows."""
    try:
        svc = get_drive_service()
        root_id = drive_find_or_create_folder(svc, DRIVE_FOLDER_ROOT)
        csv_data = drive_read_json(svc, "input.csv", root_id)
        # Note: for actual CSV, we'd use MediaIoBaseDownload, but keeping simple for demo
    except Exception:
        pass


# ══════════════════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════════
def main():
    app = Application.builder().token(TELEGRAM_TOKEN).build()

    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("status", cmd_status))
    app.add_handler(CommandHandler("resume", cmd_resume))
    app.add_handler(CommandHandler("cancel", cmd_cancel))
    app.add_handler(CallbackQueryHandler(handle_confirm_callback,
                                          pattern="^(confirm_launch|cancel_launch)$"))
    app.add_handler(CallbackQueryHandler(handle_callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    # CSV fallback watcher every 5 minutes
    app.job_queue.run_repeating(csv_watcher, interval=300, first=60)

    log.info("Bot started. Polling...")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()
